"""API key redaction helper. The full key never appears in our
own log/print output — even at DEBUG levels, even in error
messages, even when a customer pastes a stack trace into a
support ticket."""

from __future__ import annotations

from egisai._redact import redact_api_key


def test_redacts_long_egis_key_to_prefix_plus_ellipsis() -> None:
    """A real ``egis_live_…`` key shows enough prefix to
    disambiguate from other keys in logs (test vs prod) without
    leaking the secret part."""
    redacted = redact_api_key("egis_live_jblIBt8a94Gariakkhuaa0SKOr5f61trjaYjv3j-AUM")
    assert redacted == "egis_live_jb…"  # first 12 chars + ellipsis
    # Critically — the random suffix is GONE.
    assert "AUM" not in redacted
    assert "Gariakk" not in redacted


def test_redacts_short_or_test_key_completely() -> None:
    """Short test placeholders / dev keys get fully redacted —
    a 12-char window on a 12-char key would reveal the whole thing."""
    assert redact_api_key("egis_test_x") == "(redacted)"


def test_empty_or_none_renders_as_unset() -> None:
    """Distinguish "no key configured" from "redacted" — the two
    failure modes have different remediations."""
    assert redact_api_key(None) == "(unset)"
    assert redact_api_key("") == "(unset)"


def test_openai_keys_get_same_redaction_treatment() -> None:
    """Same helper handles vendor-style keys (e.g. ``sk-…``) when they
    appear in logs or error paths."""
    redacted = redact_api_key("sk-proj-FOt3Qg_P-ipH9QHlv9SMpD6huKIi4IJhk0IIiWwLAxfDZp7JEaMpXYMKyLSkD4gJgLjcVyXaJJT3BlbkFJkOkg6pLu5b")
    # First 12 chars: "sk-proj-FOt3" — the rest stays hidden.
    assert redacted == "sk-proj-FOt3…"
    assert "BlbkFJ" not in redacted
